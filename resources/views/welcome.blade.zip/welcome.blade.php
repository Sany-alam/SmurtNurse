@extends('app')



@section('content')



    <!-- Content Wrapper START -->




    <!-- Content Wrapper END -->

    <!-- Footer START -->

    <!-- Footer END -->



@endsection
